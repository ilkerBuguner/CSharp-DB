﻿using System;

namespace P03_SalesDatabase
{
    public class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}
